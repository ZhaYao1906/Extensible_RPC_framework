package com.yupi.yurpc.fault.tolerant;

import com.yupi.yurpc.model.RpcRequest;
import com.yupi.yurpc.model.RpcResponse;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 降级到其他服务 - 容错策略
 * 当原始服务调用失败时，尝试调用降级服务提供的备选实现
 *
 * @author <a href="https://github.com/liyupi">程序员鱼皮</a>
 * @learn <a href="https://codefather.cn">鱼皮的编程宝典</a>
 * @from <a href="https://yupi.icu">编程导航学习圈</a>
 */
@Slf4j
public class FailBackTolerantStrategy implements TolerantStrategy {

    /**
     * 降级服务映射表 (服务名称 -> 降级服务实现类实例)
     */
    private static final Map<String, Object> FALLBACK_SERVICE_MAP = new ConcurrentHashMap<>();

    /**
     * 注册降级服务
     * 
     * @param serviceName 服务名称
     * @param fallbackService 降级服务实现类实例
     */
    public static void registerFallbackService(String serviceName, Object fallbackService) {
        if (serviceName != null && fallbackService != null) {
            FALLBACK_SERVICE_MAP.put(serviceName, fallbackService);
            log.info("注册降级服务成功: {}", serviceName);
        }
    }

    /**
     * 检查是否有降级服务
     * 
     * @param serviceName 服务名称
     * @return 是否存在降级服务
     */
    public static boolean hasFallbackService(String serviceName) {
        return FALLBACK_SERVICE_MAP.containsKey(serviceName);
    }

    @Override
    public RpcResponse doTolerant(Map<String, Object> context, Exception e) {
        // 检查上下文是否存在
        if (context == null) {
            log.error("容错降级失败: 上下文不存在", e);
            return createErrorResponse("容错降级失败: 上下文不存在", e);
        }

        // 从上下文中获取原始RPC请求
        RpcRequest rpcRequest = (RpcRequest) context.get("rpcRequest");
        if (rpcRequest == null) {
            log.error("容错降级失败: 请求对象不存在", e);
            return createErrorResponse("容错降级失败: 请求对象不存在", e);
        }

        String serviceName = rpcRequest.getServiceName();
        String methodName = rpcRequest.getMethodName();
        Class<?>[] parameterTypes = rpcRequest.getParameterTypes();
        Object[] args = rpcRequest.getArgs();

        log.info("原始服务调用失败: {}#{}, 尝试降级处理", serviceName, methodName);
        
        // 获取降级服务
        Object fallbackService = FALLBACK_SERVICE_MAP.get(serviceName);
        if (fallbackService == null) {
            log.error("容错降级失败: 服务 {} 没有对应的降级实现", serviceName);
            return createErrorResponse("容错降级失败: 没有降级服务可用", e);
        }

        try {
            // 调用降级服务的相同方法
            Method method = fallbackService.getClass().getMethod(methodName, parameterTypes);
            Object result = method.invoke(fallbackService, args);
            
            // 构建成功响应
            RpcResponse response = new RpcResponse();
            response.setData(result);
            response.setDataType(method.getReturnType());
            response.setMessage("调用降级服务成功");
            log.info("成功降级到备选服务: {}#{}", serviceName, methodName);
            return response;
        } catch (Exception fallbackException) {
            log.error("调用降级服务失败: {}#{}", serviceName, methodName, fallbackException);
            return createErrorResponse("调用降级服务失败: " + fallbackException.getMessage(), e);
        }
    }

    /**
     * 创建错误响应
     * 
     * @param message 错误消息
     * @param e 原始异常
     * @return 错误响应对象
     */
    private RpcResponse createErrorResponse(String message, Exception e) {
        RpcResponse response = new RpcResponse();
        response.setData(null);
        response.setMessage(message);
        response.setException(e);
        return response;
    }
    
    /**
     * 使用默认值创建降级响应
     * 注意: 此方法未使用，是提供的一种可选方案
     * 
     * @param returnType 返回值类型
     * @return 返回类型的默认值
     */
    private Object getDefaultValue(Class<?> returnType) {
        if (returnType == null || returnType == void.class || returnType == Void.class) {
            return null;
        }
        
        // 基本类型默认值
        if (returnType == boolean.class) return false;
        if (returnType == byte.class) return (byte) 0;
        if (returnType == short.class) return (short) 0;
        if (returnType == int.class) return 0;
        if (returnType == long.class) return 0L;
        if (returnType == float.class) return 0.0f;
        if (returnType == double.class) return 0.0d;
        if (returnType == char.class) return '\u0000';
        
        // 默认返回null
        return null;
    }
}
