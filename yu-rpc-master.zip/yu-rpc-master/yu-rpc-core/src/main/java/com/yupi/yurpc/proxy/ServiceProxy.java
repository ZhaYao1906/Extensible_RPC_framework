package com.yupi.yurpc.proxy;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.http.HttpRequest;
import cn.hutool.http.HttpResponse;
import com.yupi.yurpc.RpcApplication;
import com.yupi.yurpc.config.RpcConfig;
import com.yupi.yurpc.constant.RpcConstant;
import com.yupi.yurpc.fault.retry.RetryStrategy;
import com.yupi.yurpc.fault.retry.RetryStrategyFactory;
import com.yupi.yurpc.fault.tolerant.TolerantStrategy;
import com.yupi.yurpc.fault.tolerant.TolerantStrategyFactory;
import com.yupi.yurpc.loadbalancer.LoadBalancer;
import com.yupi.yurpc.loadbalancer.LoadBalancerFactory;
import com.yupi.yurpc.model.RpcRequest;
import com.yupi.yurpc.model.RpcResponse;
import com.yupi.yurpc.model.ServiceMetaInfo;
import com.yupi.yurpc.registry.Registry;
import com.yupi.yurpc.registry.RegistryFactory;
import com.yupi.yurpc.serializer.Serializer;
import com.yupi.yurpc.serializer.SerializerFactory;
import com.yupi.yurpc.server.tcp.VertxTcpClient;

import java.io.IOException;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * 服务代理（JDK 动态代理）
 *
 * @author <a href="https://github.com/liyupi">程序员鱼皮</a>
 * @learn <a href="https://codefather.cn">编程宝典</a>
 * @from <a href="https://yupi.icu">编程导航知识星球</a>
 */
public class ServiceProxy implements InvocationHandler {

    /**
     * 服务发现缓存（服务名称 => 服务元信息列表）
     * 避免频繁查询注册中心
     */
    private final Map<String, CacheResult<List<ServiceMetaInfo>>> serviceDiscoveryCache = new ConcurrentHashMap<>();
    
    /**
     * 缓存过期时间（毫秒）
     */
    private static final long CACHE_EXPIRATION_TIME = 60000;
    
    /**
     * 负载均衡器缓存
     */
    private LoadBalancer loadBalancerCache;

    /**
     * 调用代理
     *
     * @return
     * @throws Throwable
     */
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        // 如果调用的是Object的方法，直接调用，不走RPC
        if (method.getDeclaringClass() == Object.class) {
            return method.invoke(this, args);
        }
        
        // 构造请求
        String serviceName = method.getDeclaringClass().getName();
        RpcRequest rpcRequest = RpcRequest.builder()
                .serviceName(serviceName)
                .methodName(method.getName())
                .parameterTypes(method.getParameterTypes())
                .args(args)
                .build();

        // 从注册中心获取服务提供者请求地址（优先使用缓存）
        List<ServiceMetaInfo> serviceMetaInfoList = getServiceMetaInfoList(serviceName);
        if (CollUtil.isEmpty(serviceMetaInfoList)) {
            throw new RuntimeException("暂无服务地址");
        }

        // 负载均衡（缓存负载均衡器实例）
        LoadBalancer loadBalancer = getLoadBalancer();
        
        // 将调用方法名（请求路径）和参数哈希值作为负载均衡参数
        Map<String, Object> requestParams = new HashMap<>();
        requestParams.put("methodName", rpcRequest.getMethodName());
        // 增加参数哈希，提高相同参数请求的一致性路由
        if (args != null && args.length > 0) {
            int paramHash = 0;
            for (Object arg : args) {
                if (arg != null) {
                    paramHash += arg.hashCode();
                }
            }
            requestParams.put("paramHash", paramHash);
        }
        
        ServiceMetaInfo selectedServiceMetaInfo = loadBalancer.select(requestParams, serviceMetaInfoList);
        if (selectedServiceMetaInfo == null) {
            throw new RuntimeException("负载均衡器选择服务失败");
        }

        // RPC 请求
        RpcResponse rpcResponse;
        try {
            // 使用重试机制
            RpcConfig rpcConfig = RpcApplication.getRpcConfig();
            RetryStrategy retryStrategy = RetryStrategyFactory.getInstance(rpcConfig.getRetryStrategy());
            rpcResponse = retryStrategy.doRetry(() ->
                    VertxTcpClient.doRequest(rpcRequest, selectedServiceMetaInfo)
            );
            
            // 检查响应状态
            if (rpcResponse == null) {
                throw new RuntimeException("RPC响应为空");
            }
            
            // 处理异常情况
            if (rpcResponse.getException() != null) {
                throw rpcResponse.getException();
            }
            
        } catch (Exception e) {
            // 容错机制
            RpcConfig rpcConfig = RpcApplication.getRpcConfig();
            TolerantStrategy tolerantStrategy = TolerantStrategyFactory.getInstance(rpcConfig.getTolerantStrategy());
            rpcResponse = tolerantStrategy.doTolerant(null, e);
            // 如果容错策略也失败了，抛出异常
            if (rpcResponse == null) {
                throw new RuntimeException("RPC调用失败", e);
            }
        }
        
        return rpcResponse.getData();
    }

    /**
     * 获取服务元信息列表（优先使用缓存）
     * 
     * @param serviceName 服务名称
     * @return 服务元信息列表
     */
    private List<ServiceMetaInfo> getServiceMetaInfoList(String serviceName) {
        // 优先从缓存中获取
        CacheResult<List<ServiceMetaInfo>> cacheResult = serviceDiscoveryCache.get(serviceName);
        if (cacheResult != null && !cacheResult.isExpired()) {
            return cacheResult.getData();
        }
        
        // 从注册中心查询
        RpcConfig rpcConfig = RpcApplication.getRpcConfig();
        Registry registry = RegistryFactory.getInstance(rpcConfig.getRegistryConfig().getRegistry());
        ServiceMetaInfo serviceMetaInfo = new ServiceMetaInfo();
        serviceMetaInfo.setServiceName(serviceName);
        serviceMetaInfo.setServiceVersion(RpcConstant.DEFAULT_SERVICE_VERSION);
        
        List<ServiceMetaInfo> serviceMetaInfoList = registry.serviceDiscovery(serviceMetaInfo.getServiceKey());
        
        // 写入缓存
        if (!CollUtil.isEmpty(serviceMetaInfoList)) {
            serviceDiscoveryCache.put(serviceName, new CacheResult<>(serviceMetaInfoList, System.currentTimeMillis() + CACHE_EXPIRATION_TIME));
        }
        
        return serviceMetaInfoList;
    }
    
    /**
     * 获取负载均衡器（使用缓存）
     */
    private LoadBalancer getLoadBalancer() {
        if (loadBalancerCache != null) {
            return loadBalancerCache;
        }
        
        RpcConfig rpcConfig = RpcApplication.getRpcConfig();
        loadBalancerCache = LoadBalancerFactory.getInstance(rpcConfig.getLoadBalancer());
        return loadBalancerCache;
    }

    /**
     * 发送 HTTP 请求
     * @param selectedServiceMetaInfo
     * @param bodyBytes
     * @return
     * @throws IOException
     */
    private static RpcResponse doHttpRequest(ServiceMetaInfo selectedServiceMetaInfo, byte[] bodyBytes) throws IOException {
        final Serializer serializer = SerializerFactory.getInstance(RpcApplication.getRpcConfig().getSerializer());
        // 发送 HTTP 请求
        try (HttpResponse httpResponse = HttpRequest.post(selectedServiceMetaInfo.getServiceAddress())
                .body(bodyBytes)
                .timeout(10000)  // 增加超时设置
                .execute()) {
            byte[] result = httpResponse.bodyBytes();
            // 反序列化
            RpcResponse rpcResponse = serializer.deserialize(result, RpcResponse.class);
            return rpcResponse;
        }
    }
    
    /**
     * 缓存结果包装类
     */
    private static class CacheResult<T> {
        private final T data;
        private final long expireTime;
        
        public CacheResult(T data, long expireTime) {
            this.data = data;
            this.expireTime = expireTime;
        }
        
        public T getData() {
            return data;
        }
        
        public boolean isExpired() {
            return System.currentTimeMillis() > expireTime;
        }
    }
}
