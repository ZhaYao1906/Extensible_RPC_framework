package com.yupi.yurpc.spi;

import cn.hutool.core.io.resource.ResourceUtil;
import com.yupi.yurpc.fault.retry.RetryStrategy;
import com.yupi.yurpc.fault.tolerant.TolerantStrategy;
import com.yupi.yurpc.loadbalancer.LoadBalancer;
import com.yupi.yurpc.registry.Registry;
import com.yupi.yurpc.serializer.Serializer;
import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.stream.Collectors;

/**
 * SPI 加载器
 * 自定义实现，支持键值对映射
 *
 * @author <a href="https://github.com/liyupi">程序员鱼皮</a>
 * @learn <a href="https://codefather.cn">程序员鱼皮的编程宝典</a>
 * @from <a href="https://yupi.icu">编程导航知识星球</a>
 */
@Slf4j
public class SpiLoader {

    /**
     * 存储已加载的类：接口名 =>（key => 实现类）
     */
    private static final Map<String, Map<String, Class<?>>> LOADER_MAP = new ConcurrentHashMap<>();

    /**
     * 对象实例缓存（避免重复 new），类路径 => 对象实例，单例模式
     */
    private static final Map<String, Object> INSTANCE_CACHE = new ConcurrentHashMap<>();

    /**
     * 读写锁，用于并发控制
     */
    private static final ReentrantReadWriteLock LOCK = new ReentrantReadWriteLock();
    private static final ReentrantReadWriteLock.ReadLock READ_LOCK = LOCK.readLock();
    private static final ReentrantReadWriteLock.WriteLock WRITE_LOCK = LOCK.writeLock();

    /**
     * 系统 SPI 目录
     */
    private static final String RPC_SYSTEM_SPI_DIR = "META-INF/rpc/system/";

    /**
     * 用户自定义 SPI 目录
     */
    private static final String RPC_CUSTOM_SPI_DIR = "META-INF/rpc/custom/";

    /**
     * 扫描路径
     */
    private static final String[] SCAN_DIRS = new String[]{RPC_SYSTEM_SPI_DIR, RPC_CUSTOM_SPI_DIR};

    /**
     * 动态加载的类列表
     */
    private static final List<Class<?>> LOAD_CLASS_LIST = Arrays.asList(
            Serializer.class,
            LoadBalancer.class,
            Registry.class,
            RetryStrategy.class,
            TolerantStrategy.class
    );

    /**
     * 私有构造函数，防止实例化
     */
    private SpiLoader() {
    }

    /**
     * 加载所有类型
     */
    public static void loadAll() {
        log.info("开始加载所有 SPI 接口");
        for (Class<?> interfaceClass : LOAD_CLASS_LIST) {
            load(interfaceClass);
        }
        log.info("所有 SPI 接口加载完成，共加载了 {} 个接口", LOADER_MAP.size());
    }

    /**
     * 获取某个接口的实例
     *
     * @param interfaceClass 接口类
     * @param key            配置文件中的键名
     * @param <T>            接口类型
     * @return 实现类实例
     * @throws RuntimeException 如果加载失败
     */
    public static <T> T getInstance(Class<?> interfaceClass, String key) {
        // 参数校验
        if (interfaceClass == null) {
            throw new IllegalArgumentException("接口类不能为空");
        }
        if (key == null || key.isEmpty()) {
            throw new IllegalArgumentException("SPI 键名不能为空");
        }

        String interfaceName = interfaceClass.getName();
        
        // 尝试从缓存获取
        READ_LOCK.lock();
        try {
            // 获取已加载的映射
            Map<String, Class<?>> keyClassMap = LOADER_MAP.get(interfaceName);
            
            // 如果映射不存在，尝试加载
            if (keyClassMap == null) {
                READ_LOCK.unlock(); // 释放读锁
                WRITE_LOCK.lock(); // 获取写锁
                try {
                    // 双重检查
                    keyClassMap = LOADER_MAP.get(interfaceName);
                    if (keyClassMap == null) {
                        keyClassMap = load(interfaceClass);
                    }
                    READ_LOCK.lock(); // 获取读锁
                } finally {
                    WRITE_LOCK.unlock(); // 释放写锁
                }
            }
            
            // 检查键是否存在
            if (!keyClassMap.containsKey(key)) {
                throw new RuntimeException(String.format("SPI 加载器中找不到接口 %s 对应的键 %s", interfaceName, key));
            }
            
            // 获取实现类
            Class<?> implClass = keyClassMap.get(key);
            String implClassName = implClass.getName();
            
            // 从实例缓存中获取或创建实例
            if (!INSTANCE_CACHE.containsKey(implClassName)) {
                READ_LOCK.unlock(); // 释放读锁
                WRITE_LOCK.lock(); // 获取写锁
                try {
                    // 双重检查
                    if (!INSTANCE_CACHE.containsKey(implClassName)) {
                        try {
                            Object instance = implClass.getDeclaredConstructor().newInstance();
                            INSTANCE_CACHE.put(implClassName, instance);
                            log.debug("创建并缓存了 {} 的实例", implClassName);
                        } catch (ReflectiveOperationException e) {
                            String errorMsg = String.format("实例化 %s 类失败", implClassName);
                            log.error(errorMsg, e);
                            throw new RuntimeException(errorMsg, e);
                        }
                    }
                    READ_LOCK.lock(); // 重新获取读锁
                } finally {
                    WRITE_LOCK.unlock(); // 释放写锁
                }
            }
            
            // 返回实例
            return (T) INSTANCE_CACHE.get(implClassName);
        } finally {
            READ_LOCK.unlock(); // 最终释放读锁
        }
    }

    /**
     * 获取接口的所有实现类实例
     *
     * @param interfaceClass 接口类
     * @param <T>            接口类型
     * @return 实现类实例映射 (key -> 实例)
     */
    public static <T> Map<String, T> getAllInstances(Class<?> interfaceClass) {
        if (interfaceClass == null) {
            throw new IllegalArgumentException("接口类不能为空");
        }
        
        String interfaceName = interfaceClass.getName();
        Map<String, Class<?>> keyClassMap;
        
        // 获取或加载接口映射
        READ_LOCK.lock();
        try {
            keyClassMap = LOADER_MAP.get(interfaceName);
            if (keyClassMap == null) {
                READ_LOCK.unlock();
                WRITE_LOCK.lock();
                try {
                    keyClassMap = LOADER_MAP.get(interfaceName);
                    if (keyClassMap == null) {
                        keyClassMap = load(interfaceClass);
                    }
                    READ_LOCK.lock();
                } finally {
                    WRITE_LOCK.unlock();
                }
            }
            
            // 创建结果映射
            Map<String, T> result = new HashMap<>(keyClassMap.size());
            for (Map.Entry<String, Class<?>> entry : keyClassMap.entrySet()) {
                String key = entry.getKey();
                result.put(key, getInstance(interfaceClass, key));
            }
            return result;
        } finally {
            READ_LOCK.unlock();
        }
    }

    /**
     * 加载某个类型
     *
     * @param interfaceClass 接口类
     * @return 键到实现类的映射
     */
    public static Map<String, Class<?>> load(Class<?> interfaceClass) {
        if (interfaceClass == null) {
            throw new IllegalArgumentException("接口类不能为空");
        }
        
        String interfaceName = interfaceClass.getName();
        log.info("加载 SPI 接口: {}", interfaceName);
        
        WRITE_LOCK.lock();
        try {
            // 检查是否已加载
            if (LOADER_MAP.containsKey(interfaceName)) {
                return LOADER_MAP.get(interfaceName);
            }
            
            // 扫描路径，用户自定义的 SPI 优先级高于系统 SPI
            Map<String, Class<?>> keyClassMap = new HashMap<>();
            
            // 加载配置
            for (String scanDir : SCAN_DIRS) {
                String resourcePath = scanDir + interfaceName;
                List<URL> resources = ResourceUtil.getResources(resourcePath);
                
                // 读取每个资源文件
                for (URL resource : resources) {
                    log.debug("读取 SPI 配置文件: {}", resource.getPath());
                    try (InputStreamReader inputStreamReader = new InputStreamReader(resource.openStream(), StandardCharsets.UTF_8);
                         BufferedReader bufferedReader = new BufferedReader(inputStreamReader)) {
                        
                        // 读取每行配置
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            // 忽略注释和空行
                            line = line.trim();
                            if (line.isEmpty() || line.startsWith("#")) {
                                continue;
                            }
                            
                            // 解析键值对
                            String[] parts = line.split("=", 2);
                            if (parts.length == 2) {
                                String key = parts[0].trim();
                                String className = parts[1].trim();
                                
                                // 用户自定义配置会覆盖系统配置
                                if (!keyClassMap.containsKey(key) || scanDir.equals(RPC_CUSTOM_SPI_DIR)) {
                                    try {
                                        Class<?> clazz = Class.forName(className);
                                        
                                        // 验证是否实现了接口
                                        if (!interfaceClass.isAssignableFrom(clazz)) {
                                            log.warn("类 {} 未实现接口 {}, 已忽略", className, interfaceName);
                                            continue;
                                        }
                                        
                                        keyClassMap.put(key, clazz);
                                        log.debug("加载 SPI 实现类: {} => {}", key, className);
                                    } catch (ClassNotFoundException e) {
                                        log.error("找不到 SPI 实现类: {}", className, e);
                                    }
                                }
                            }
                        }
                    } catch (IOException e) {
                        log.error("读取 SPI 配置文件失败: {}", resource.getPath(), e);
                    }
                }
            }
            
            // 如果没有找到任何实现，记录警告
            if (keyClassMap.isEmpty()) {
                log.warn("接口 {} 没有找到任何 SPI 实现", interfaceName);
            } else {
                log.info("接口 {} 加载了 {} 个 SPI 实现: {}", 
                    interfaceName, 
                    keyClassMap.size(), 
                    keyClassMap.keySet().stream().collect(Collectors.joining(", ")));
            }
            
            // 保存到加载映射中
            LOADER_MAP.put(interfaceName, keyClassMap);
            return keyClassMap;
        } finally {
            WRITE_LOCK.unlock();
        }
    }

    /**
     * 清除加载和实例缓存
     */
    public static void clear() {
        WRITE_LOCK.lock();
        try {
            LOADER_MAP.clear();
            INSTANCE_CACHE.clear();
            log.info("SPI 加载器缓存已清除");
        } finally {
            WRITE_LOCK.unlock();
        }
    }

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        loadAll();
        System.out.println(LOADER_MAP);
        Serializer serializer = getInstance(Serializer.class, "e");
        System.out.println(serializer);
    }
}
