package com.yupi.yurpc.loadbalancer;

/**
 * 负载均衡器键名常量
 *
 * @author <a href="https://github.com/liyupi">程序员鱼皮</a>
 * @learn <a href="https://codefather.cn">鱼皮的编程宝典</a>
 * @from <a href="https://yupi.icu">编程导航学习圈</a>
 */
public interface LoadBalancerKeys {
    /**
     * 轮询
     */
    String ROUND_ROBIN = "roundRobin";

    String RANDOM = "random";

    String CONSISTENT_HASH = "consistentHash";

    /**
     * 加权轮询
     */
    String WEIGHTED_ROUND_ROBIN = "weightedRoundRobin";
    
    /**
     * 加权随机
     */
    String WEIGHTED_RANDOM = "weightedRandom";
}
