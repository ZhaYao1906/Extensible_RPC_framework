package com.yupi.yurpc;

import com.yupi.yurpc.config.RegistryConfig;
import com.yupi.yurpc.config.RpcConfig;
import com.yupi.yurpc.constant.RpcConstant;
import com.yupi.yurpc.registry.Registry;
import com.yupi.yurpc.registry.RegistryFactory;
import com.yupi.yurpc.utils.ConfigUtils;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * RPC 框架应用
 * 相当于 holder，存放了项目全局用到的变量。双检锁单例模式实现
 *
 * @author <a href="https://github.com/liyupi">程序员鱼皮</a>
 * @learn <a href="https://codefather.cn">程序员鱼皮的编程宝典</a>
 * @from <a href="https://yupi.icu">编程导航知识星球</a>
 */
@Slf4j
public class RpcApplication {

    /**
     * 全局RPC配置
     */
    private static volatile RpcConfig rpcConfig;
    
    /**
     * 是否已初始化标志
     */
    private static final AtomicBoolean INITIALIZED = new AtomicBoolean(false);
    
    /**
     * 注册中心实例
     */
    private static Registry registry;

    /**
     * 私有构造函数，防止实例化
     */
    private RpcApplication() {
    }

    /**
     * 框架初始化，支持传入自定义配置
     * 
     * @param newRpcConfig 自定义RPC配置
     * @throws IllegalStateException 如果已经初始化过，则抛出异常
     */
    public static synchronized void init(RpcConfig newRpcConfig) {
        // 防止重复初始化
        if (INITIALIZED.get()) {
            log.warn("RPC application has been initialized, ignore this operation");
            return;
        }
        
        if (newRpcConfig == null) {
            throw new IllegalArgumentException("RPC config cannot be null");
        }
        
        try {
            log.info("Initializing RPC application with config: {}", newRpcConfig);
            rpcConfig = newRpcConfig;
            
            // 注册中心初始化
            RegistryConfig registryConfig = rpcConfig.getRegistryConfig();
            registry = RegistryFactory.getInstance(registryConfig.getRegistry());
            registry.init(registryConfig);
            log.info("Registry initialized: {}", registryConfig);
            
            // 创建并注册 Shutdown Hook，JVM 退出时执行操作
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                log.info("Shutting down RPC application...");
                destroy();
            }));
            
            // 标记为已初始化
            INITIALIZED.set(true);
            log.info("RPC application initialized successfully");
        } catch (Exception e) {
            log.error("Failed to initialize RPC application", e);
            throw new RuntimeException("Failed to initialize RPC application", e);
        }
    }

    /**
     * 使用默认配置初始化
     */
    public static void init() {
        RpcConfig newRpcConfig;
        try {
            newRpcConfig = ConfigUtils.loadConfig(RpcConfig.class, RpcConstant.DEFAULT_CONFIG_PREFIX);
            log.info("Loaded RPC config from default location");
        } catch (Exception e) {
            log.warn("Failed to load config from default location, using default values", e);
            // 配置加载失败，使用默认值
            newRpcConfig = new RpcConfig();
        }
        init(newRpcConfig);
    }

    /**
     * 获取配置，如果未初始化则进行初始化
     * 
     * @return RPC配置对象
     */
    public static RpcConfig getRpcConfig() {
        if (rpcConfig == null) {
            synchronized (RpcApplication.class) {
                if (rpcConfig == null) {
                    init();
                }
            }
        }
        return rpcConfig;
    }
    
    /**
     * 获取注册中心实例
     * 
     * @return 注册中心实例
     */
    public static Registry getRegistry() {
        if (registry == null) {
            getRpcConfig(); // 确保已初始化
        }
        return registry;
    }
    
    /**
     * 销毁资源
     */
    public static synchronized void destroy() {
        if (!INITIALIZED.get()) {
            return;
        }
        
        if (registry != null) {
            try {
                registry.destroy();
                log.info("Registry destroyed");
            } catch (Exception e) {
                log.error("Error destroying registry", e);
            }
            registry = null;
        }
        
        rpcConfig = null;
        INITIALIZED.set(false);
        log.info("RPC application destroyed");
    }
    
    /**
     * 判断是否已经初始化
     * 
     * @return 是否已初始化
     */
    public static boolean isInitialized() {
        return INITIALIZED.get();
    }
}
