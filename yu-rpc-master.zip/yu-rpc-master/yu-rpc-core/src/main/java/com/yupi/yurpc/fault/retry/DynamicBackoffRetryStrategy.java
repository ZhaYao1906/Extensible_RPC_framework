package com.yupi.yurpc.fault.retry;

import com.github.rholder.retry.*;
import com.yupi.yurpc.model.RpcResponse;
import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;

/**
 * 动态可变延迟重试策略
 * 根据先前重试的成功或失败情况，动态调整下一次重试的延迟时间
 */
@Slf4j
public class DynamicBackoffRetryStrategy implements RetryStrategy {

    /**
     * 1、初始退避时间（毫秒）
     */
    private final long initialBackoffMs;

    /**
     * 2、最大退避时间（毫秒）
     */
    private final long maxBackoffMs;

    /**
    * 3、最大重试次数
     */
    private final int maxAttempts;

    /**
     * 4、退避因子（每次重试失败后，延迟时间将乘以此因子）
     */
    private final double backoffFactor;

    /**
     * 5、成功减少因子（重试成功后，下次初始延迟时间将乘以此因子，降低重试延迟）
     */
    private final double successReductionFactor;

    /**
     * 6、当前初始退避时间（会根据历史成功/失败动态调整）
     */
    private final AtomicInteger currentInitialBackoffMs = new AtomicInteger();

    /**
     * 7、使用默认参数构造器
     */
    public DynamicBackoffRetryStrategy() {
        this(1000, 60000, 5, 2.0, 0.5);
    }

    /**
     * 完全自定义参数构造器
     *
     * @param initialBackoffMs 初始退避时间（毫秒）
     * @param maxBackoffMs 最大退避时间（毫秒）
     * @param maxAttempts 最大重试次数
     * @param backoffFactor 退避因子
     * @param successReductionFactor 成功减少因子
     */
    public DynamicBackoffRetryStrategy(
            long initialBackoffMs,
            long maxBackoffMs,
            int maxAttempts,
            double backoffFactor,
            double successReductionFactor) {
        this.initialBackoffMs = initialBackoffMs;
        this.maxBackoffMs = maxBackoffMs;
        this.maxAttempts = maxAttempts;
        this.backoffFactor = backoffFactor;
        this.successReductionFactor = successReductionFactor;
        this.currentInitialBackoffMs.set((int) initialBackoffMs);
    }

    @Override
    public RpcResponse doRetry(Callable<RpcResponse> callable) throws ExecutionException, RetryException {
        // 使用预定义的固定等待策略，并在监听器中动态调整
        WaitStrategy waitStrategy = WaitStrategies.exponentialWait(
                currentInitialBackoffMs.get(), maxBackoffMs, TimeUnit.MILLISECONDS);

        // 自定义重试监听器，用于根据重试结果动态调整初始退避时间
        RetryListener retryListener = new RetryListener() {
            @Override
            public <V> void onRetry(Attempt<V> attempt) {
                long attemptNumber = attempt.getAttemptNumber();
                log.info("重试次数: {}", attemptNumber);
                
                // 第一次调用不是重试
                if (attemptNumber == 1) {
                    return;
                }
                
                // 计算当前退避时间：初始退避时间 * 退避因子^(重试次数-1)
                double currentBackoff = currentInitialBackoffMs.get() * Math.pow(backoffFactor, attemptNumber - 2);
                // 限制最大退避时间
                long waitTime = (long) Math.min(currentBackoff, maxBackoffMs);
                log.info("第 {} 次重试，等待时间约: {}ms", attemptNumber - 1, waitTime);
                
                // 判断本次尝试是否成功
                if (attempt.hasException()) {
                    // 失败了，可以考虑增加初始退避时间，但这里不调整，保持当前值
                    log.info("第 {} 次重试失败，保持初始退避时间: {}ms", attemptNumber, currentInitialBackoffMs.get());
                } else {
                    // 成功了，降低初始退避时间，但不低于最初设置的初始值
                    int newBackoff = (int) Math.max(
                            initialBackoffMs, 
                            currentInitialBackoffMs.get() * successReductionFactor);
                    currentInitialBackoffMs.set(newBackoff);
                    log.info("第 {} 次重试成功，降低初始退避时间至: {}ms", attemptNumber, newBackoff);
                }
            }
        };

        // 构建重试器
        Retryer<RpcResponse> retryer = RetryerBuilder.<RpcResponse>newBuilder()
                // 发生任何异常都重试
                .retryIfException()
                // 使用指数退避等待策略
                .withWaitStrategy(waitStrategy)
                // 设置最大重试次数
                .withStopStrategy(StopStrategies.stopAfterAttempt(maxAttempts))
                // 添加重试监听器
                .withRetryListener(retryListener)
                .build();

        try {
            // 执行重试调用
            RpcResponse response = retryer.call(callable);
            
            // 调用成功后，适当降低初始退避时间（除非已经是最低值）
            if (currentInitialBackoffMs.get() > initialBackoffMs) {
                int newBackoff = (int) Math.max(
                        initialBackoffMs, 
                        currentInitialBackoffMs.get() * successReductionFactor);
                currentInitialBackoffMs.set(newBackoff);
                log.info("调用最终成功，降低下次初始退避时间至: {}ms", newBackoff);
            }
            
            return response;
        } catch (ExecutionException | RetryException e) {
            // 重试最终失败，增加初始退避时间，但不超过最大值
            int newBackoff = (int) Math.min(
                    maxBackoffMs, 
                    currentInitialBackoffMs.get() * backoffFactor);
            currentInitialBackoffMs.set(newBackoff);
            log.info("重试最终失败，增加下次初始退避时间至: {}ms", newBackoff);
            throw e;
        }
    }
} 