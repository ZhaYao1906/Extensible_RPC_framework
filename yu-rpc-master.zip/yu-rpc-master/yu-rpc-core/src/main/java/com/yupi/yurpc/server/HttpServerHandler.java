package com.yupi.yurpc.server;

import com.yupi.yurpc.RpcApplication;
import com.yupi.yurpc.model.RpcRequest;
import com.yupi.yurpc.model.RpcResponse;
import com.yupi.yurpc.registry.LocalRegistry;
import com.yupi.yurpc.serializer.Serializer;
import com.yupi.yurpc.serializer.SerializerFactory;
import io.vertx.core.Handler;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.http.HttpServerRequest;
import io.vertx.core.http.HttpServerResponse;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * HTTP 请求处理器
 *
 * @author <a href="https://github.com/liyupi">程序员鱼皮</a>
 * @learn <a href="https://codefather.cn">编程宝典</a>
 * @from <a href="https://yupi.icu">编程导航知识星球</a>
 */
public class HttpServerHandler implements Handler<HttpServerRequest> {

    /**
     * 日志记录器
     */
    private static final Logger LOGGER = Logger.getLogger(HttpServerHandler.class.getName());

    /**
     * 服务实例缓存，避免重复创建服务实例
     * key: 服务名称，value: 服务实例
     */
    private static final Map<String, Object> SERVICE_INSTANCE_CACHE = new ConcurrentHashMap<>();
    
    /**
     * 方法缓存，避免重复反射获取方法
     * key: 服务名称:方法名称:参数类型hash，value: 方法对象
     */
    private static final Map<String, Method> METHOD_CACHE = new ConcurrentHashMap<>();
    
    /**
     * 序列化器实例（单例）
     */
    private final Serializer serializer;
    
    /**
     * 构造方法
     */
    public HttpServerHandler() {
        // 初始化序列化器
        this.serializer = SerializerFactory.getInstance(RpcApplication.getRpcConfig().getSerializer());
    }

    @Override
    public void handle(HttpServerRequest request) {
        // 记录日志
        LOGGER.info("Received request: " + request.method() + " " + request.uri());

        // 异步处理 HTTP 请求
        request.bodyHandler(body -> {
            RpcResponse rpcResponse = new RpcResponse();
            
            try {
                // 反序列化请求
                byte[] bytes = body.getBytes();
                RpcRequest rpcRequest = serializer.deserialize(bytes, RpcRequest.class);
                
                // 如果请求为 null，直接返回
                if (rpcRequest == null) {
                    rpcResponse.setMessage("rpcRequest is null");
                    doResponse(request, rpcResponse);
                    return;
                }
                
                // 处理请求调用服务
                Object result = invokeService(rpcRequest, rpcResponse);
                
                // 封装返回结果
                if (result != null) {
                    rpcResponse.setData(result);
                }
                
                if (rpcResponse.getMessage() == null) {
                    rpcResponse.setMessage("ok");
                }
                
            } catch (Exception e) {
                LOGGER.log(Level.SEVERE, "处理请求异常", e);
                rpcResponse.setMessage(e.getMessage());
                rpcResponse.setException(e);
            }
            
            // 响应
            doResponse(request, rpcResponse);
        });
    }

    /**
     * 调用服务
     * 
     * @param rpcRequest RPC请求
     * @param rpcResponse RPC响应（用于设置错误信息）
     * @return 调用结果
     */
    private Object invokeService(RpcRequest rpcRequest, RpcResponse rpcResponse) {
        try {
            // 获取服务名称
            String serviceName = rpcRequest.getServiceName();
            String methodName = rpcRequest.getMethodName();
            Class<?>[] parameterTypes = rpcRequest.getParameterTypes();
            
            // 生成方法缓存key
            String methodCacheKey = generateMethodCacheKey(serviceName, methodName, parameterTypes);
            
            // 从缓存获取方法
            Method method = METHOD_CACHE.get(methodCacheKey);
            if (method == null) {
                // 获取服务实现类
                Class<?> implClass = LocalRegistry.get(serviceName);
                if (implClass == null) {
                    throw new RuntimeException("未找到服务实现类: " + serviceName);
                }
                
                // 获取方法
                method = implClass.getMethod(methodName, parameterTypes);
                METHOD_CACHE.put(methodCacheKey, method);
            }
            
            // 从缓存获取服务实例
            Object serviceInstance = SERVICE_INSTANCE_CACHE.get(serviceName);
            if (serviceInstance == null) {
                Class<?> implClass = LocalRegistry.get(serviceName);
                serviceInstance = implClass.newInstance();
                SERVICE_INSTANCE_CACHE.put(serviceName, serviceInstance);
            }
            
            // 调用方法
            Object result = method.invoke(serviceInstance, rpcRequest.getArgs());
            
            // 设置返回类型
            rpcResponse.setDataType(method.getReturnType());
            
            return result;
        } catch (InvocationTargetException e) {
            // 如果是目标方法抛出的异常，提取原始异常
            Throwable targetException = e.getTargetException();
            LOGGER.log(Level.WARNING, "服务方法执行异常", targetException);
            
            // 如果是Exception类型，则设置到响应中
            if (targetException instanceof Exception) {
                rpcResponse.setException((Exception) targetException);
            } else {
                // 否则封装为RuntimeException
                rpcResponse.setException(new RuntimeException(targetException.getMessage(), targetException));
            }
            return null;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "服务调用异常", e);
            rpcResponse.setException(e);
            return null;
        }
    }
    
    /**
     * 生成方法缓存key
     */
    private String generateMethodCacheKey(String serviceName, String methodName, Class<?>[] parameterTypes) {
        StringBuilder key = new StringBuilder(serviceName).append(':').append(methodName);
        if (parameterTypes != null) {
            for (Class<?> parameterType : parameterTypes) {
                key.append(':').append(parameterType.getName());
            }
        }
        return key.toString();
    }

    /**
     * 响应客户端
     *
     * @param request HTTP请求
     * @param rpcResponse RPC响应
     */
    private void doResponse(HttpServerRequest request, RpcResponse rpcResponse) {
        HttpServerResponse httpServerResponse = request.response()
                .putHeader("content-type", "application/json");
                
        try {
            // 序列化
            byte[] serialized = serializer.serialize(rpcResponse);
            httpServerResponse.end(Buffer.buffer(serialized));
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "序列化响应失败", e);
            // 返回空响应
            httpServerResponse.setStatusCode(500)
                    .end(Buffer.buffer("{\"message\":\"Internal server error\"}"));
        }
    }
}
