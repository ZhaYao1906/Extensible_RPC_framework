package com.yupi.yurpc.loadbalancer;

import com.yupi.yurpc.model.ServiceMetaInfo;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 加权轮询负载均衡器
 */
public class WeightedRoundRobinLoadBalancer implements LoadBalancer {

    /**
     * 当前轮询位置
     */
    private final AtomicInteger currentIndex = new AtomicInteger(0);

    /**
     * 服务权重映射表 (服务地址 => 权重)
     */
    private final Map<String, Integer> weightMap = new HashMap<>();

    /**
     * 默认权重
     */
    private static final int DEFAULT_WEIGHT = 100;

    @Override
    public ServiceMetaInfo select(Map<String, Object> requestParams, List<ServiceMetaInfo> serviceMetaInfoList) {
        if (serviceMetaInfoList == null || serviceMetaInfoList.isEmpty()) {
            return null;
        }

        // 构建权重列表
        List<WeightedService> weightedServices = new ArrayList<>();
        int totalWeight = 0;

        for (ServiceMetaInfo serviceMetaInfo : serviceMetaInfoList) {
            String serviceAddress = serviceMetaInfo.getServiceAddress();
            // 获取服务权重，默认为 DEFAULT_WEIGHT
            int weight = weightMap.getOrDefault(serviceAddress, DEFAULT_WEIGHT);
            weightedServices.add(new WeightedService(serviceMetaInfo, weight));
            totalWeight += weight;
        }

        if (totalWeight <= 0) {
            return null;
        }

        // 递增当前索引
        int currentPosition = currentIndex.incrementAndGet() % totalWeight;
        
        // 根据权重选择服务
        int position = 0;
        for (WeightedService weightedService : weightedServices) {
            position += weightedService.getWeight();
            if (currentPosition <= position) {
                return weightedService.getServiceMetaInfo();
            }
        }

        // 兜底返回第一个服务
        return serviceMetaInfoList.get(0);
    }

    /**
     * 设置服务权重
     *
     * @param serviceAddress 服务地址
     * @param weight        权重值
     */
    public void setWeight(String serviceAddress, int weight) {
        if (weight > 0) {
            weightMap.put(serviceAddress, weight);
        }
    }

    /**
     * 带权重的服务包装类
     */
    private static class WeightedService {
        private final ServiceMetaInfo serviceMetaInfo;
        private final int weight;

        public WeightedService(ServiceMetaInfo serviceMetaInfo, int weight) {
            this.serviceMetaInfo = serviceMetaInfo;
            this.weight = weight;
        }

        public ServiceMetaInfo getServiceMetaInfo() {
            return serviceMetaInfo;
        }

        public int getWeight() {
            return weight;
        }
    }
} 