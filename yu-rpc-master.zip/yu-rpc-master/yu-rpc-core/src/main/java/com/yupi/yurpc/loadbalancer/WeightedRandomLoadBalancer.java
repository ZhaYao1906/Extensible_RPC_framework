package com.yupi.yurpc.loadbalancer;

import com.yupi.yurpc.model.ServiceMetaInfo;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * 加权随机负载均衡器
 */
public class WeightedRandomLoadBalancer implements LoadBalancer {

    /**
     * 服务权重映射表 (服务地址 => 权重)
     */
    private final Map<String, Integer> weightMap = new HashMap<>();

    /**
     * 默认权重
     */
    private static final int DEFAULT_WEIGHT = 100;

    @Override
    public ServiceMetaInfo select(Map<String, Object> requestParams, List<ServiceMetaInfo> serviceMetaInfoList) {
        if (serviceMetaInfoList == null || serviceMetaInfoList.isEmpty()) {
            return null;
        }

        // 构建加权随机选择列表
        List<WeightedService> weightedServices = new ArrayList<>();
        int totalWeight = 0;

        // 计算总权重并创建加权服务列表
        for (ServiceMetaInfo serviceMetaInfo : serviceMetaInfoList) {
            String serviceAddress = serviceMetaInfo.getServiceAddress();
            // 获取服务权重，默认为 DEFAULT_WEIGHT
            int weight = weightMap.getOrDefault(serviceAddress, DEFAULT_WEIGHT);
            weightedServices.add(new WeightedService(serviceMetaInfo, weight));
            totalWeight += weight;
        }

        // 如果总权重为0或负数，则无法进行加权选择
        if (totalWeight <= 0) {
            // 直接随机选择，不考虑权重
            int index = ThreadLocalRandom.current().nextInt(serviceMetaInfoList.size());
            return serviceMetaInfoList.get(index);
        }

        // 生成一个随机数，范围是[0, totalWeight)
        int randomWeight = ThreadLocalRandom.current().nextInt(totalWeight);
        
        // 根据权重选择服务
        int currentWeight = 0;
        for (WeightedService weightedService : weightedServices) {
            currentWeight += weightedService.getWeight();
            // 当累计权重大于等于随机值时，选中当前服务
            if (randomWeight < currentWeight) {
                return weightedService.getServiceMetaInfo();
            }
        }

        // 兜底返回最后一个服务（正常不会走到这里）
        return serviceMetaInfoList.get(serviceMetaInfoList.size() - 1);
    }

    /**
     * 设置服务权重
     *
     * @param serviceAddress 服务地址
     * @param weight        权重值
     */
    public void setWeight(String serviceAddress, int weight) {
        if (weight > 0) {
            weightMap.put(serviceAddress, weight);
        }
    }

    /**
     * 获取服务权重
     * @param serviceAddress 服务地址
     * @return 权重值，如果未设置则返回默认权重
     */
    public int getWeight(String serviceAddress) {
        return weightMap.getOrDefault(serviceAddress, DEFAULT_WEIGHT);
    }

    /**
     * 带权重的服务包装类
     */
    private static class WeightedService {
        private final ServiceMetaInfo serviceMetaInfo;
        private final int weight;

        public WeightedService(ServiceMetaInfo serviceMetaInfo, int weight) {
            this.serviceMetaInfo = serviceMetaInfo;
            this.weight = weight;
        }

        public ServiceMetaInfo getServiceMetaInfo() {
            return serviceMetaInfo;
        }

        public int getWeight() {
            return weight;
        }
    }
} 